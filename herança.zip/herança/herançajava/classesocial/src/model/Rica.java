package model;

public class Rica extends RendaDasPessoas {
    public Rica() {
        super(273175.00);
    }

}
