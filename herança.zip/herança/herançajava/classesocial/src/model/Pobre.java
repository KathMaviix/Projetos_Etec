package model;

public class Pobre extends RendaDasPessoas {
    public Pobre() {
        super(43064.00);
    }

}
