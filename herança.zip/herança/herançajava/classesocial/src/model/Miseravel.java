package model;

public class Miseravel extends RendaDasPessoas {
    public Miseravel() {
        super(10105.00);
    }

}
