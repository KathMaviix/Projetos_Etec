package principal;

public class veiculo {

}
