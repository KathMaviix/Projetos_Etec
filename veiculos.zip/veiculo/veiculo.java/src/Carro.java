public class Carro {

}
